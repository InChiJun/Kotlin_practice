fun main(args: Array <String>) {
    val playerName: String = "Estragon";
    var experiencePoints: Int = 5;
    experiencePoints += 5;
    println(experiencePoints);
    println(playerName);
}